//
//  SearchViewController.h
//  TestApp
//
//  Created by WeMited Mac 3 on 09/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Header.h"
#import "SearchTableCell.h"

#import "SearchDetailViewController.h"
#import "SerialsViewController.h"
#import "DBManager.h"


#import "UIImageView+WebCache.h"

@interface SearchViewController : UIViewController <UITableViewDelegate, UISearchBarDelegate,UITableViewDataSource,UITextFieldDelegate,UISearchControllerDelegate,UISearchBarDelegate,UISearchResultsUpdating,UISearchDisplayDelegate>

@property(nonatomic,strong)  UITableView *moviesTableView;
@property (nonatomic,strong) UISearchController *searchController;
@property(nonatomic,strong) UISearchBar *search_7;


@property (nonatomic, strong) DBManager *dbManager;
@property (nonatomic, strong) NSArray *totalArray;

@property(nonatomic,strong) UIView *replyerBackHeadingView;
@property(nonatomic,strong)UILabel *totalResult;

@property(nonatomic,strong)UIButton *nextPageButton,*previousPage;

@end
