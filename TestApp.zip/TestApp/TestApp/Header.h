//
//  Header.h
//  TestApp
//
//  Created by WeMited Mac 3 on 09/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#define TestApp_Header_h
#import <Availability.h>

#ifndef __IPHONE_3_0
#warning "This project uses features only available in iOS SDK 3.0 and later."
#endif

#ifdef __OBJC__
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


#define isPhone ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
#define isPhone_5 (isPhone && [[UIScreen mainScreen] bounds].size.height == 568.0f)
#define DEVICE_SIZE [UIScreen mainScreen].bounds.size


#define customGreenTextColor [UIColor colorWithRed:33.0f/255.0f green:84.0f/255.0f blue:83.0f/255.0f alpha:1.0f]
#define headingColor [UIColor colorWithRed:235.0f/255.0f green:235.0f/255.0f blue:235.0f/255.0f alpha:1.0f]
#define customGreenColor [UIColor colorWithRed:106.0f/255.0f green:167.0f/255.0f blue:80.0f/255.0f alpha:1.0f]


#define footerHeight 44
#define title_hight 44
#define title_padding 5
#define title_logo_hight_width 34



#define customGreen [UIColor colorWithRed:55.0f/255.0f green:167.0f/255.0f blue:60.0f/255.0f alpha:1.0f]



#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)


#define kBaseUrl @"http://www.omdbapi.com/?"


#endif
