//
//  SerialsViewController.h
//  TestApp
//
//  Created by WeMited Mac 3 on 15/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Header.h"
#import "SerialViewCell.h"
#import "SearchDetailViewController.h"
#import "UIImageView+WebCache.h"

@interface SerialsViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UIButton *backBtn;
@property(nonatomic,strong) UILabel *headingLabel;
@property(nonatomic,strong) UITableView *seriaseTable;


@property(nonatomic,strong) NSString *sendDBId;

@end
