//
//  SearchTableCell.h
//  TestApp
//
//  Created by WeMited Mac 3 on 10/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Header.h"

@interface SearchTableCell : UITableViewCell

@property(nonatomic,strong) UILabel *backgroundLabel;
@property(nonatomic,strong) UIImageView *profilePic;
@property(nonatomic,strong) UILabel *titleName;
@property(nonatomic,strong) UILabel *languages;
@property(nonatomic,strong) UILabel *year;
@property(nonatomic,strong) UILabel *more_btn;

@end
