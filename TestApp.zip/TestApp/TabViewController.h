//
//  TabViewController.h
//  TestApp
//
//  Created by WeMited Mac 3 on 09/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Header.h"
#import "FeatureViewController.h"
#import "SearchViewController.h"
#import "ProfileViewController.h"

@interface TabViewController : UIViewController <UITabBarControllerDelegate>

@property(nonatomic,strong) UITabBarController *tabBarController;


@end
