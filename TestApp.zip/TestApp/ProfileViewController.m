//
//  ProfileViewController.m
//  TestApp
//
//  Created by WeMited Mac 3 on 09/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#import "ProfileViewController.h"

@interface ProfileViewController ()

@end

@implementation ProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor whiteColor];
    
    
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"sample.sql"];
    [self loadData];
    
    
    [self SetUpDesign];
}


-(void)SetUpDesign{
    
    
    
    self.headingLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, DEVICE_SIZE.width, title_hight)];
    self.headingLabel.backgroundColor=customGreen;
    self.headingLabel.textAlignment = NSTextAlignmentCenter;
    self.headingLabel.textColor = [UIColor whiteColor];
    self.headingLabel.clipsToBounds = YES;
    self.headingLabel.numberOfLines = 1;
    self.headingLabel.baselineAdjustment = YES;
    self.headingLabel.adjustsFontSizeToFitWidth = NO;
    [self.headingLabel setText:@"Setting"];
    [self.headingLabel setFont:[UIFont boldSystemFontOfSize:18]];
    
    
    self.settingsTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, title_hight, DEVICE_SIZE.width, DEVICE_SIZE.height-title_hight)];
    
    self.settingsTableView.bounces=YES;
    
    
    
    [self.view addSubview:self.headingLabel];
    
    [self.view addSubview:self.settingsTableView];
    [self.settingsTableView setDelegate:self];
    [self.settingsTableView setDataSource:self];
}

-(void)loadData{
    
    
    
    
//    NSString *query = @"INSERT INTO sett VALUES (1,0,1,0)";
    
    NSString *query = @"SELECT * FROM sett";

    if (self.totalArray != nil) {
        self.totalArray = nil;
    }
    self.totalArray = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
    
    NSLog(@"Total flag 1 Table = %@",self.totalArray);

    
//    UPDATE Customers
//    SET ContactName='Alfred Schmidt', City='Hamburg'
//    WHERE CustomerName='Alfreds Futterkiste';
    
    
//    NSString *flage1 = @"select * from sett where id=1";
//    if (self.selected_image_array != nil) {
//        self.selected_image_array = nil;
//    }
//    self.selected_image_array = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:flage1]];
//    
//    NSLog(@"Total flag 1 Table = %@",self.selected_image_array);
//    
//    [self.game_Image_Collection reloadData];
    
    
    
}




- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    
    UILabel * sectionHeader = [[UILabel alloc] initWithFrame:CGRectZero] ;
    sectionHeader.backgroundColor = [UIColor clearColor];
    sectionHeader.font = [UIFont boldSystemFontOfSize:10];
    sectionHeader.textColor = headingColor;
    
    switch (section)
    {
        case 0:
            sectionHeader.text = @"Search By";
            sectionHeader.textAlignment = NSTextAlignmentCenter;
            break;
        case 1:
            sectionHeader.text = @"Search Type";
            sectionHeader.textAlignment = NSTextAlignmentCenter;
            break;
        default:
            sectionHeader.text = @"";
            break;
    }
    return sectionHeader.text;
}




- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    if (section == 0)
        return 1;
    else
        return 1;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
    
    
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    static NSString *simpleTableIdentifier = @"cell";
    
    SettingVewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    
    if (cell == nil) {
        cell = [[SettingVewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
        
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    
    
//    cell.listItemsNameLbl.textAlignment = NSTextAlignmentLeft;
//    cell.listItemsNameLbl.textColor = customGreenTextColor;
//    cell.listItemsNameLbl.clipsToBounds = YES;
//    cell.listItemsNameLbl.numberOfLines = 1;
//    cell.listItemsNameLbl.baselineAdjustment = YES;
//    cell.listItemsNameLbl.adjustsFontSizeToFitWidth = NO;
//    
//    
//    [cell.off_on_switch addTarget:self action:@selector(ToggleAction:) forControlEvents:UIControlEventValueChanged];
//    cell.off_on_switch.backgroundColor=[UIColor clearColor];
//    
//    
//    
    if (indexPath.section==0) {
        
        if (indexPath.row==0) {
            
            
            NSArray *setValueArray;
            
            NSString *query = @"SELECT * FROM sett";
            
            if (setValueArray != nil) {
                setValueArray = nil;
            }
            setValueArray = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
            
            NSLog(@"Total flag 1 Table = %@",setValueArray);
            
            if ([[NSString stringWithFormat:@"%@",[[setValueArray objectAtIndex:0] objectAtIndex:0]]intValue]==1) {
                [cell.segementControl setSelectedSegmentIndex:0];

            }
            else{
                [cell.segementControl setSelectedSegmentIndex:1];

            }
            
            
            cell.segementControl.frame = CGRectMake(DEVICE_SIZE.width/4, 10, DEVICE_SIZE.width/2, 40);
            cell.segementControl.tintColor=customGreen;

            [cell.segementControl addTarget:self action:@selector(name_id_dbId:) forControlEvents:UIControlEventValueChanged];

            
            
            
        }

        
    }
    else {
        
        
        if (indexPath.row==0) {
            
            
            
            
            NSArray *setValueArray;
            
            NSString *query = @"SELECT * FROM sett";
            
            if (setValueArray != nil) {
                setValueArray = nil;
            }
            setValueArray = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
            
            NSLog(@"Total flag 1 Table = %@",setValueArray);
            
            if ([[NSString stringWithFormat:@"%@",[[setValueArray objectAtIndex:0] objectAtIndex:2]]intValue]==1) {
                [cell.segementControlType_m_s setSelectedSegmentIndex:0];
                
            }
            else{
                [cell.segementControlType_m_s setSelectedSegmentIndex:1];
                
            }
            
            cell.segementControlType_m_s.frame = CGRectMake(DEVICE_SIZE.width/4, 10, DEVICE_SIZE.width/2, 40);
            cell.segementControlType_m_s.tintColor=customGreen;
            [cell.segementControlType_m_s addTarget:self action:@selector(Movies_series:) forControlEvents:UIControlEventValueChanged];

        }
               
        
        
    }
    
    
   
    
    NSLog( @"Count %ld",(long)indexPath.row);
    
    
    
    
    return cell;
    
}

-(void)name_id_dbId:(UISegmentedControl *)sender{
    
    
    if (sender.selectedSegmentIndex == 0) {
        
       
        
        
        NSArray *setValueArray;
        
        NSString *query = @"UPDATE sett SET id=1,dbId=0";
        
        if (setValueArray != nil) {
            setValueArray = nil;
        }
        setValueArray = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
        
        NSLog(@"Total flag 1 Table = %@",setValueArray);
        
        
        
        
    }
    else {
        
        
        NSArray *setValueArray;
        
        NSString *query = @"UPDATE sett SET dbId=1,id=0";
        
        if (setValueArray != nil) {
            setValueArray = nil;
        }
        setValueArray = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
        
        NSLog(@"Total flag 1 Table = %@",setValueArray);

        
        
    }
    
}


-(void)Movies_series:(UISegmentedControl *)sender{
    
    
    if (sender.selectedSegmentIndex == 0) {
        
        
        NSArray *setValueArray;
        
        NSString *query = @"UPDATE sett SET movies=1,series=0";
        
        if (setValueArray != nil) {
            setValueArray = nil;
        }
        setValueArray = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
        
        NSLog(@"Total flag 1 Table = %@",setValueArray);
        

        
        
    }
    else
    {
        
        
        NSArray *setValueArray;
        
        NSString *query = @"UPDATE sett SET series=1,movies=0";
        
        if (setValueArray != nil) {
            setValueArray = nil;
        }
        setValueArray = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
        
        NSLog(@"Total flag 1 Table = %@",setValueArray);
        

        
    }
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    
    
    if (indexPath.section==0) {
        
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        
    }
    else {
        
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        
        
    }
    
    
    
    
    
}







- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
