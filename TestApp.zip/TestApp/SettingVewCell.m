//
//  SettingVewCell.m
//  TestApp
//
//  Created by WeMited Mac 3 on 12/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#import "SettingVewCell.h"

@implementation SettingVewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        
        self.frame=CGRectMake(0, 0, DEVICE_SIZE.width, 60);
        
        
        NSArray *serchArray=[[NSArray alloc]initWithObjects:@"Name",@"Id", nil];
        self.segementControl=[[UISegmentedControl alloc]initWithItems:serchArray];
        self.segementControl.frame = CGRectMake(0, 0, 0, 0);
        
        [self addSubview:self.segementControl];
        
        
        
        NSArray *serchArray_m_s=[[NSArray alloc]initWithObjects:@"Movies",@"Serial", nil];
        self.segementControlType_m_s=[[UISegmentedControl alloc]initWithItems:serchArray_m_s];
        self.segementControlType_m_s.frame = CGRectMake(0, 0, 0, 0);
        
        [self addSubview:self.segementControlType_m_s];
        
        
    }
    return self;
}


@end
