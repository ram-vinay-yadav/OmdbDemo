//
//  ProfileViewController.h
//  TestApp
//
//  Created by WeMited Mac 3 on 09/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Header.h"
#import "SettingVewCell.h"


#import "DBManager.h"
@interface ProfileViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,strong) UILabel *headingLabel;
@property(nonatomic,strong)  UITableView *settingsTableView;

@property (nonatomic, strong) DBManager *dbManager;
@property (nonatomic, strong) NSArray *totalArray;


@end
