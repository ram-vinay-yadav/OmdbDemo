//
//  SearchViewController.m
//  TestApp
//
//  Created by WeMited Mac 3 on 09/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#import "SearchViewController.h"

@interface SearchViewController ()
{
    NSString *searchStr;
    NSData *searchData;
    NSMutableDictionary *searchJson;
    
    
    
    NSMutableArray *searchResults;
    NSMutableArray *row_no;
    NSString *searchText;
    UISearchDisplayController *searchDisplayController;
    
    
    int page_numberValue;
    int  name_dbIdStr;
    int  searchType;
    
    int seasion;
}
@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
    page_numberValue=1;
    
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"sample.sql"];
    [self loadData];

    
    
    [self setUpDesign];
}



#pragma mark - setUpDesign

-(void)setUpDesign{
    
    
    
    
    
    
    self.search_7=[[UISearchBar alloc]init];
    self.search_7.frame=CGRectMake(0, 0, DEVICE_SIZE.width, 44);
    self.search_7.backgroundColor=[UIColor whiteColor];
    self.search_7.placeholder = @"Start searching...";
    [self.search_7 setValue:[UIColor lightGrayColor] forKeyPath:@"_searchField._placeholderLabel.textColor"];


    self.search_7.showsCancelButton=NO;
    self.search_7.delegate=self;
    
    
    self.moviesTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, self.search_7.frame.origin.y+self.search_7.frame.size.height, DEVICE_SIZE.width, DEVICE_SIZE.height-self.search_7.frame.origin.y-self.search_7.frame.size.height-49)];
    self.moviesTableView.backgroundColor=[UIColor whiteColor];
    self.moviesTableView.separatorStyle=UITableViewCellSelectionStyleNone;
    self.moviesTableView.bounces=YES;
    
    
    
    
    
    
    [self.view addSubview:self.search_7];
    
    
    [self.view addSubview:self.moviesTableView];
    [self.moviesTableView setDelegate:self];
    [self.moviesTableView setDataSource:self];
    [self.moviesTableView reloadData];
    
    
}


-(void)BackBtnSelector:(UIButton *)sender{
    
    
    [self.navigationController popViewControllerAnimated:NO];
}



#pragma mark - viewWillAppear


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:NO];
    
    self.searchController.active=NO;
}

#pragma mark - viewWillDisappear

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:NO];
    
    self.searchController.active=NO;
    
    [self.searchDisplayController setActive:NO animated:NO];
}



#pragma mark - SearchBar Delegate


- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar{
    return YES;
}
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar{
    NSLog(@"Search start");
    
    
    [searchBar setShowsCancelButton:YES animated:YES];
    
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar{
    
    
    
    [searchBar setShowsCancelButton:NO animated:YES];

    
    NSLog(@"Search end");
    
    searchText=searchBar.text;
    NSLog(@"Search Text String :%@",searchText);

    if (![searchText isEqualToString:@""]) {
        [self CallWebServiceForMyCourse ];
        NSLog(@"Searching... :%@",searchText);

        
    }
    else{
        [self.search_7 resignFirstResponder];
    }
    
    
}


#pragma mark - UISearchBarDelegate

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    
   
    
    
    [self.search_7 resignFirstResponder];
    
    
}

- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar
{
    [searchBar setShowsCancelButton:NO animated:YES];
}


#pragma mark - UISearchBarDelegate

// Workaround for bug: -updateSearchResultsForSearchController: is not called when scope buttons change
- (void)searchBar:(UISearchBar *)searchBar selectedScopeButtonIndexDidChange:(NSInteger)selectedScope {
    [self updateSearchResultsForSearchController:self.searchController];
}



#pragma mark - UISearchResultsUpdating

- (void)updateSearchResultsForSearchController:(UISearchController *)searchController {
    
    // update the filtered array based on the search text
    
    searchText = self.searchController.searchBar.text;
    
    
    NSLog(@"searchdelegate is called in eventviewController");
    
    
  }


-(BOOL)searchDisplayController:(UISearchDisplayController *)controller
shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterContentForSearchText:searchString
                               scope:[[self.searchDisplayController.searchBar scopeButtonTitles]
                                      objectAtIndex:[self.searchDisplayController.searchBar
                                                     selectedScopeButtonIndex]]];
    
    return YES;
}
- (void)filterContentForSearchText:(NSString*)searchTextt scope:(NSString*)scope
{
    
    searchText=searchTextt;
    
    NSLog(@"search text is : %@",searchText);
    
    
  }



-(void)searchDisplayControllerDidEndSearch:(UISearchDisplayController *)controller
{
    [row_no removeAllObjects];
    searchText=nil;
    
    self.searchDisplayController.searchBar.translatesAutoresizingMaskIntoConstraints = YES;
    [self.searchDisplayController setActive:NO animated:YES];
    [searchDisplayController.searchBar  setShowsCancelButton:NO animated:NO];
    [searchDisplayController.searchBar setFrame:CGRectMake(0, 0, DEVICE_SIZE.width, 44) ];
    
    
    [self.moviesTableView reloadData];
    
    
}
- (void) searchDisplayControllerWillBeginSearch:(UISearchDisplayController *)controller
{
    self.searchDisplayController.searchBar.showsCancelButton=NO;
    [controller.searchBar setFrame:CGRectMake(0, 0, DEVICE_SIZE.width, 44)];
    [self.searchDisplayController.searchResultsTableView setDelegate:self];
    
    
    
}


-(void)CancelSearch
{
    
    [self.searchDisplayController setActive:NO animated:YES];
    [searchDisplayController.searchBar  setShowsCancelButton:NO animated:NO];
    [self.view endEditing:YES];
    
    [self.moviesTableView reloadData];
    
}






-(void)AddCourseMeQuize:(UIButton *)sender{
    
   
    
}

-(void)loadData{
    
    NSString *query = @"SELECT * FROM sett";
    NSArray *setValueArray;
    if (setValueArray != nil) {
        setValueArray = nil;
    }
    setValueArray = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
    NSLog(@"Total flag 1 Table = %@",setValueArray);
    
    
    
    if (setValueArray == nil || [setValueArray count] == 0) {
        
        NSString *query = @"INSERT INTO sett VALUES (1,0,1,0)";
        
        if (self.totalArray != nil) {
            self.totalArray = nil;
        }
        self.totalArray = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
        
        NSLog(@"Total flag 1 Table = %@",self.totalArray);

    }
    
    
   
    
    
    
}




#pragma  mark - CallWebService get_my_course

-(void) CallWebServiceForMyCourse
{
    
    
   
    NSArray *setValueArray;
    
    NSString *query = @"SELECT * FROM sett";
    
    if (setValueArray != nil) {
        setValueArray = nil;
    }
    setValueArray = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
    
    NSLog(@"Total flag 1 Table = %@",setValueArray);
    
    if ([[NSString stringWithFormat:@"%@",[[setValueArray objectAtIndex:0] objectAtIndex:0]]intValue]==1) {
        name_dbIdStr=0;
    }
    else if ([[NSString stringWithFormat:@"%@",[[setValueArray objectAtIndex:0] objectAtIndex:1]]intValue]==1) {
        name_dbIdStr=1;
    }else
    {
        
    }
        
    if ([[NSString stringWithFormat:@"%@",[[setValueArray objectAtIndex:0] objectAtIndex:2]]intValue]==1) {
        searchType=0;
        
    }else if ([[NSString stringWithFormat:@"%@",[[setValueArray objectAtIndex:0] objectAtIndex:3]]intValue]==1) {
        searchType=1;
    }
    else{
        
    }
    
    NSString *searchTypeStr;
    
    if (searchType==0) {
        searchTypeStr=@"movies";
    }
    else{
        searchTypeStr=@"series";

    }
    
    
    
    
    if ([searchTypeStr isEqualToString:@"series"]) {
    
    
    if (name_dbIdStr==0) {
        searchStr = [[NSString stringWithFormat:@"%@s=%@&plot=short&r=json&page=%d&seasion=1",kBaseUrl,searchText,page_numberValue] stringByReplacingOccurrencesOfString:@" " withString:@"%20"];

    }
    else {
        
        searchStr = [[NSString stringWithFormat:@"%@t=%@&plot=short&r=json&page=%d&seasion=1",kBaseUrl,searchText,page_numberValue] stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    }
    
    }
    else{
        
        
        if (name_dbIdStr==0) {
            searchStr = [[NSString stringWithFormat:@"%@s=%@&plot=short&r=json&page=%d",kBaseUrl,searchText,page_numberValue] stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
            
        }
        else {
            
            searchStr = [[NSString stringWithFormat:@"%@t=%@&plot=short&r=json&page=%d",kBaseUrl,searchText,page_numberValue] stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
        }

        
        
    }
    
    
    
    
    NSLog(@"login string is with email :  %@ ",searchStr);
    
    
    
//    UIActivityIndicatorView *activityView = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
//    activityView.center=self.view.center;
//    activityView.color=customGreenColor;
//    activityView.hidesWhenStopped=YES;
//    [self.view addSubview:activityView];
//    
//    dispatch_async(dispatch_get_main_queue(), ^{
//        
//        [activityView startAnimating];
//    });
    
    dispatch_async(kBgQueue, ^{
        
        
        searchData = [NSData dataWithContentsOfURL:[NSURL URLWithString:searchStr]];
        
        // NSString *sttr=[[NSString alloc] initWithData:myCourseData encoding:NSUTF8StringEncoding];
        // NSLog(@"data responce is : %@",sttr);
        
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if(searchData!=nil)
            {
                
                NSError* error;
                
                searchJson = [NSJSONSerialization
                                JSONObjectWithData:searchData
                                options:kNilOptions
                                error:&error];
                
                NSString *success_no=[NSString stringWithFormat:@"%@",[searchJson valueForKey:@"Response"]];
                if([success_no isEqualToString:@"True"])
                {
                    
                    [self.view addSubview:self.moviesTableView];
                    [self.moviesTableView setDelegate:self];
                    [self.moviesTableView setDataSource:self];
                    [self.moviesTableView reloadData];
                    
                    
                    
                }
                else if([success_no isEqualToString:@"False"])
                {
                    
                    
                    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_0) {
                        
                        
                        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Sorry" message:@"False Responce." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                        [alert show];
                        
                        
                    } else {
                        UIAlertController * alert=   [UIAlertController alertControllerWithTitle:@"Sorry"message:@"False Responce." preferredStyle:UIAlertControllerStyleAlert];
                        UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"Ok"style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];
                        }];
                        
                        [alert addAction:cancelBtn];
                        [self presentViewController:alert animated:YES completion:nil];
                        
                        
                    }
                    
                }
                
                else{
                    
                    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_0) {
                        
                        
                        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert" message:[searchJson valueForKey:@"Response"] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                        [alert show];
                        
                        
                    } else {
                        UIAlertController * alert=   [UIAlertController alertControllerWithTitle:@"Alert"message:[searchJson valueForKey:@"Response"] preferredStyle:UIAlertControllerStyleAlert];
                        UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"Ok"style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];
                        }];
                        
                        [alert addAction:cancelBtn];
                        [self presentViewController:alert animated:YES completion:nil];
                        
                        
                    }
                    
                    
                }
                
            }
            else
            {
                
                if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_0) {
                    
                    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Internet is not working on your device." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                    [alert show];
                    
                } else {
                    UIAlertController * alert=   [UIAlertController alertControllerWithTitle:@"Alert"message:@"Internet is not working on your device." preferredStyle:UIAlertControllerStyleAlert];
                    UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"Ok"style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                        [alert dismissViewControllerAnimated:YES completion:nil];
                    }];
                    
                    [alert addAction:cancelBtn];
                    [self presentViewController:alert animated:YES completion:nil];
                    
                }
                
            }
            
            
            
            
        });
        
       // [activityView stopAnimating];
        
    });
    
}


-(void)NextPage:(UIButton *)sender{
 
    
    page_numberValue++;
    
    [self CallWebServiceForMyCourse];
    
    
    [self.moviesTableView reloadData];
    
}


-(void)PreviousPage:(UIButton *)sender{
    
    
    page_numberValue--;
    
    [self CallWebServiceForMyCourse];
 
    [self.moviesTableView reloadData];

}



#pragma mark - tableView Delegates



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    self.replyerBackHeadingView=[[UIView alloc]initWithFrame:CGRectNull];
    self.replyerBackHeadingView.backgroundColor=[UIColor lightGrayColor];
    
    self.totalResult=[[UILabel alloc]init];
    self.totalResult.frame=CGRectMake(100+5 ,5,tableView.frame.size.width-200, 30 );
    
    [self.totalResult setText:[NSString stringWithFormat:@"%@ Results",[searchJson objectForKey:@"totalResults"]]];
    self.totalResult.textAlignment = NSTextAlignmentCenter;
    self.totalResult.textColor = [UIColor darkGrayColor];
    self.totalResult.clipsToBounds = YES;
    self.totalResult.numberOfLines = 1;
    self.totalResult.baselineAdjustment = YES;
    self.totalResult.adjustsFontSizeToFitWidth = NO;
    [self.totalResult setFont:[UIFont boldSystemFontOfSize:14]];
   
    
    
    
    self.previousPage=[[UIButton alloc]init];
    self.previousPage.frame=CGRectMake(10 ,5,100, 30 );
    self.previousPage.backgroundColor=[UIColor clearColor];
    self.previousPage.layer.borderWidth=1;
    self.previousPage.layer.borderColor=[[UIColor darkGrayColor] CGColor];
    self.previousPage.layer.cornerRadius=4;
    self.previousPage.clipsToBounds=YES;
    [self.previousPage setTitle:@"Previous" forState:UIControlStateNormal];
    [self.previousPage setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.previousPage addTarget:self action:@selector(PreviousPage:) forControlEvents:UIControlEventTouchUpInside];
    

    
    
    self.nextPageButton=[[UIButton alloc]init];
    self.nextPageButton.frame=CGRectMake(tableView.frame.size.width-100 ,5,95, 30 );
    self.nextPageButton.backgroundColor=[UIColor clearColor];
    self.nextPageButton.layer.borderWidth=1;
    self.nextPageButton.layer.borderColor=[[UIColor darkGrayColor] CGColor];
    self.nextPageButton.layer.cornerRadius=4;
    self.nextPageButton.clipsToBounds=YES;
    [self.nextPageButton setTitle:@"Next Page" forState:UIControlStateNormal];
    [self.nextPageButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.nextPageButton addTarget:self action:@selector(NextPage:) forControlEvents:UIControlEventTouchUpInside];
    

    if (page_numberValue>1) {
        
        [self.replyerBackHeadingView addSubview:self.previousPage];
    }
    
    

    [self.replyerBackHeadingView addSubview:self.nextPageButton];
    [self.replyerBackHeadingView addSubview:self.totalResult];
    
    self.moviesTableView.tableHeaderView = self.replyerBackHeadingView;
    
    return self.replyerBackHeadingView;
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    
    if ([searchJson objectForKey:@"totalResults"]>0) {
        return 40;

    }
    else{
        return 0;

    }
    return 0;

}




- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return [[searchJson objectForKey:@"Search"]count];
    
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 160;
}


- (void)searchDisplayController:(UISearchDisplayController *)controller didLoadSearchResultsTableView:(UITableView *)tableView
{
    tableView.rowHeight = 80;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    static NSString *simpleTableIdentifier = @"cell";
    
    SearchTableCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    
    if (cell == nil) {
        cell = [[SearchTableCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
        
        
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    
    if (indexPath.row%2==0) {
        cell.backgroundColor=[UIColor lightGrayColor];

    }
    else{
        cell.backgroundColor=[UIColor lightGrayColor];

    }
    
    
    [cell.backgroundLabel.layer setBorderColor:[UIColor whiteColor].CGColor];
    [cell.backgroundLabel.layer setBorderWidth:1.0f];
    cell.backgroundLabel.layer.cornerRadius=2;
    cell.backgroundLabel.backgroundColor=[UIColor whiteColor];

    
    cell.profilePic.backgroundColor=[UIColor clearColor];
    [cell.profilePic setContentMode:UIViewContentModeScaleAspectFit];
    cell.profilePic.layer.cornerRadius = 2;
    cell.profilePic.layer.masksToBounds = YES;
    cell.profilePic.layer.borderWidth = 0;
    cell.profilePic.layer.borderColor=[[UIColor whiteColor] CGColor];
    

    
    
    
    
//    Poster = "http://ia.media-imdb.com/images/M/MV5BNzYwNjU2MDUyMl5BMl5BanBnXkFtZTcwNDcwMDAyMQ@@._V1_SX300.jpg";
//    Title = "Adventures of Don Juan";
//    Type = movie;
//    Year = 1948;
//    imdbID = tt0040076;
    
    
    cell.titleName.backgroundColor=[UIColor clearColor];
    cell.titleName.textAlignment = NSTextAlignmentLeft;
    cell.titleName.textColor = customGreenTextColor;
    cell.titleName.clipsToBounds = YES;
    cell.titleName.numberOfLines = 2;
    cell.titleName.baselineAdjustment = YES;
    cell.titleName.adjustsFontSizeToFitWidth = NO;
    [cell.titleName setFont:[UIFont boldSystemFontOfSize:14]];
    cell.titleName.text=[NSString stringWithFormat:@"%@",[[[searchJson objectForKey:@"Search"] objectAtIndex:indexPath.row] objectForKey:@"Title"]];
    
    
    
    
    cell.year.backgroundColor=[UIColor clearColor];
    cell.year.textAlignment = NSTextAlignmentLeft;
    cell.year.textColor = customGreenTextColor;
    cell.year.clipsToBounds = YES;
    cell.year.numberOfLines = 1;
    cell.year.baselineAdjustment = YES;
    cell.year.adjustsFontSizeToFitWidth = NO;
    [cell.year setFont:[UIFont fontWithName:@"Helvetica" size:14]];
    cell.year.text=[NSString stringWithFormat:@"  %@",[[[searchJson objectForKey:@"Search"] objectAtIndex:indexPath.row] objectForKey:@"Year"]];


    
    cell.languages.backgroundColor=[UIColor redColor];
    cell.languages.textAlignment = NSTextAlignmentLeft;
    cell.languages.textColor = customGreenTextColor;
    cell.languages.clipsToBounds = YES;
    cell.languages.numberOfLines = 1;
    cell.languages.baselineAdjustment = YES;
    cell.languages.adjustsFontSizeToFitWidth = NO;
    [cell.languages setFont:[UIFont fontWithName:@"Helvetica" size:12]];
    

    cell.more_btn.backgroundColor=customGreen;
    cell.more_btn.clipsToBounds = YES;
    cell.more_btn.text=@"View More";
    cell.more_btn.textColor=[UIColor whiteColor];
    cell.more_btn.textAlignment=NSTextAlignmentCenter;
    
    
//    [cell.more_btn setTitle:@"View More" forState:UIControlStateNormal];
//    [cell.more_btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    cell.more_btn.layer.cornerRadius=3;
    cell.more_btn.clipsToBounds=YES;
    
    
    
    [cell.profilePic sd_setImageWithPreviousCachedImageWithURL:[NSURL URLWithString:[[[searchJson objectForKey:@"Search"] objectAtIndex:indexPath.row] objectForKey:@"Poster"] ] andPlaceholderImage:[UIImage imageNamed:@"placeholder@2x.png"] options:SDWebImageRetryFailed progress:^(NSInteger receivedSize, NSInteger expectedSize) {
    } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        
    }];
    
    
    
    
    
//    if (indexPath.row) {
//        dispatch_async(dispatch_get_main_queue(), ^{
//            cell.titleName.numberOfLines = 0;
//            [cell.titleName sizeToFit];
//            
//        });
//        
//    }else if (indexPath.row==0) {
//        dispatch_async(dispatch_get_main_queue(), ^{
//            cell.titleName.numberOfLines = 0;
//            [cell.titleName sizeToFit];
//            
//        });
//        
//    }
//    else{
//        
//    }
    
     
     
    
    return cell;
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
    
//    if (indexPath.row %2==0) {
//        SearchDetailViewController *search_Detail=[[SearchDetailViewController alloc]init];
//        [self.navigationController pushViewController:search_Detail animated:NO];
//    }
//    else{
//        SerialsViewController *series_Detail=[[SerialsViewController alloc]init];
//        [self.navigationController pushViewController:series_Detail animated:NO];
//    }
    
    
    if ([[[[searchJson objectForKey:@"Search"] objectAtIndex:indexPath.row] objectForKey:@"Type"]isEqualToString:@"movie"]) {
        SearchDetailViewController *search_Detail=[[SearchDetailViewController alloc]init];
        search_Detail.dbId=[NSString stringWithFormat:@"%@",[[[searchJson objectForKey:@"Search"] objectAtIndex:indexPath.row] objectForKey:@"imdbID"]];
        [self.navigationController pushViewController:search_Detail animated:NO];
    }
    else{
        SerialsViewController *series_Detail=[[SerialsViewController alloc]init];
        series_Detail.sendDBId=[NSString stringWithFormat:@"%@",[[[searchJson objectForKey:@"Search"] objectAtIndex:indexPath.row] objectForKey:@"Title"]];
        [self.navigationController pushViewController:series_Detail animated:NO];
    }
    
}


#pragma mark - touches click

- (void)touchesBegan:(NSSet * )touches withEvent:(UIEvent *)event {
    
    [self.view endEditing:YES];
    
    UITouch *touch = [[event allTouches] anyObject];
    
    if (![[touch view] isKindOfClass:[UITextField class]]) {
        [self.view endEditing:YES];
    }
    [super touchesBegan:touches withEvent:event];
}


#pragma mark - didReceiveMemoryWarning

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
