//
//  TabViewController.m
//  TestApp
//
//  Created by WeMited Mac 3 on 09/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#import "TabViewController.h"

@interface TabViewController ()

@end

@implementation TabViewController

-(void)viewWillAppear:(BOOL)animated{
    
    [self createTabs];
    
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor lightGrayColor];
    
}




-(void)createTabs
{
    
    
    UIViewController *calender = [[FeatureViewController alloc]init];
    calender.tabBarItem = [[UITabBarItem alloc]initWithTabBarSystemItem:UITabBarSystemItemFavorites tag:1];
    UINavigationController *calenderNavController = [[UINavigationController alloc]initWithRootViewController:calender];
    
    
    
    UIViewController *client = [[SearchViewController alloc]init];
    client.tabBarItem = [[UITabBarItem alloc]initWithTabBarSystemItem:UITabBarSystemItemFavorites tag:2];
    UINavigationController *clientNavController = [[UINavigationController alloc]initWithRootViewController:client];
    
    
    UIViewController *program = [[ProfileViewController alloc]init];
    program.tabBarItem = [[UITabBarItem alloc]initWithTabBarSystemItem:UITabBarSystemItemFavorites tag:3];
    UINavigationController *programNavController = [[UINavigationController alloc]initWithRootViewController:program];
    
    
        
    
    self.tabBarController = [[UITabBarController alloc] init];
    CGRect frame = CGRectMake(0.0, 0.0, DEVICE_SIZE.width, self.tabBarController.tabBar.frame.size.height);
    UIView *v = [[UIView alloc] initWithFrame:frame];
    [v setBackgroundColor:[UIColor lightGrayColor]];
    
    [v setAlpha:1.0];
    [[self.tabBarController tabBar] insertSubview:v atIndex:0];
    
    
    self.tabBarController.viewControllers = [[NSArray alloc] initWithObjects:calenderNavController,clientNavController,programNavController,nil];
    
    
    //    self.tabBarController.viewControllers = [[NSArray alloc] initWithObjects:calenderNavController,clientNavController,programNavController,stopwatchNavController,businessAnalyticNavController,invoiceNavController,nil];
    self.tabBarController.tabBar.layer.borderWidth=0.01f;
    //self.tabBarController.tabBar.layer.borderColor=DarkBlue.CGColor;
    self.tabBarController.tabBarItem.imageInsets=UIEdgeInsetsMake(1.0f, 1.0f, 1.0f, 1.0f);
    [[UITabBar appearance] setBackgroundImage:[[UIImage alloc]init]];
    [self.tabBarController.tabBar setClipsToBounds:TRUE];
    
    self.tabBarController.selectedIndex=0;
    
    float numOfTabs=0;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        // The device is an iPad running iOS 3.2 or later.
        numOfTabs=3;
    }
    else
    {
        // The device is an iPhone or iPod touch.
        numOfTabs=3;
    }
    
    self.tabBarController.tabBar.layer.borderWidth = 0.0f;
    self.tabBarController.tabBar.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    CGSize imageSize = CGSizeMake(DEVICE_SIZE.width/numOfTabs, self.tabBarController.tabBar.frame.size.height);
    //UIColor *fillColor=[UIColor colorWithRed:0.0f/255.0f green:160.0f/255.0f blue:227.0f/255.0f alpha:1];
    UIColor *fillColor = [UIColor blueColor];
    UIGraphicsBeginImageContextWithOptions(imageSize, YES, 0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    [fillColor setFill];
    CGContextFillRect(context, CGRectMake(0, 0, imageSize.width, imageSize.height));
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    
    [[UITabBar appearance] setSelectionIndicatorImage:image];
    
    calenderNavController.tabBarItem =
    [[UITabBarItem alloc] initWithTitle:@"Scan"
                                  image:[UIImage imageNamed:@"feature@2x"]
                                    tag:1];
    clientNavController.tabBarItem =
    [[UITabBarItem alloc] initWithTitle:@"Search"
                                  image:[UIImage imageNamed:@"find@2x.png"]
                                    tag:2];
    programNavController.tabBarItem =
    [[UITabBarItem alloc] initWithTitle:@"Setting"
                                  image:[UIImage imageNamed:@"gear@2x.png"]
                                    tag:3];
    
    
    
    calenderNavController.navigationBarHidden=YES;
    clientNavController.navigationBarHidden=YES;
    programNavController.navigationBarHidden=YES;
    
    [[UITabBarItem appearance] setTitleTextAttributes: [NSDictionary dictionaryWithObjectsAndKeys: [UIColor whiteColor], NSForegroundColorAttributeName,[UIFont fontWithName:@"Helvetica" size:14.0], NSFontAttributeName, nil] forState: UIControlStateNormal];
    [self settabbarImage];
    self.tabBarController.delegate=self;
    //self.view.window.rootViewController=self.tabBarController;
    self.navigationController.navigationBarHidden=YES;
    [self.navigationController pushViewController:self.tabBarController animated:NO];
    
    
//    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor blackColor] }
//                                             forState:UIControlStateNormal];
    
}



-(void)settabbarImage{
    for (UITabBarItem *item in self.tabBarController.tabBar.items) {
        switch (item.tag) {
            case 1:
            {
                
                [item setImage:[[UIImage imageNamed:@"feature@2x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
                [item setSelectedImage:[[UIImage imageNamed:@"feature@2x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
                
                
                break;
            }
            case 2:
            {
                
                [item setImage:[[UIImage imageNamed:@"find@2x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
                [item setSelectedImage:[[UIImage imageNamed:@"find@2x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
                
                break;
                
            }
            case 3:
            {
                [item setImage:[[UIImage imageNamed:@"gear@2x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
                [item setSelectedImage:[[UIImage imageNamed:@"gear@2x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
                break;
            }
            

                
            default:
            {
                [item setImage:[[UIImage imageNamed:@"more@2x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
                [item setSelectedImage:[[UIImage imageNamed:@"more@2x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
                
                break;
            }
        }
        
    }
    
}




- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
    NSLog(@"selected view controller : %@",viewController);
    
    NSLog(@"selected %lu",(unsigned long)tabBarController.selectedIndex);
}

- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController {
    
    NSLog(@"selected should selected %lu",(unsigned long)tabBarController.selectedIndex);
    
    return YES;
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
