//
//  SearchDetailViewController.h
//  TestApp
//
//  Created by WeMited Mac 3 on 12/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Header.h"
#import "UIImageView+WebCache.h"

@interface SearchDetailViewController : UIViewController


@property(nonatomic,strong)UIButton *backBtn;
@property(nonatomic,strong)UILabel *headingLabel;
@property(nonatomic,strong)UIButton *shareBtn;
@property(nonatomic,retain) UIDocumentInteractionController *documentationInteractionController;
@property(nonatomic,strong)UIScrollView *detailScrollView;

@property(nonatomic,strong)UIImageView *bannerImage;
@property(nonatomic,strong) NSString *dbId;




@property(nonatomic,strong) UILabel *title_name,*release_date,*run_time,*gener,*languase,*director,*actor,*ploat;

@end
