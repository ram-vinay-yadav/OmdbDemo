//
//  SerialViewCell.h
//  TestApp
//
//  Created by WeMited Mac 3 on 15/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Header.h"

@interface SerialViewCell : UITableViewCell

@property(nonatomic,strong) UILabel *backgroundLabel;
@property(nonatomic,strong) UIImageView *images;
@property(nonatomic,strong) UILabel *titleName;
@property(nonatomic,strong) UILabel *releaseDate;

@end
