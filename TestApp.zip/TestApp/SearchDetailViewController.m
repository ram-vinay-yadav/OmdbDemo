//
//  SearchDetailViewController.m
//  TestApp
//
//  Created by WeMited Mac 3 on 12/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#import "SearchDetailViewController.h"

@interface SearchDetailViewController (){
    NSString *detailsStr;
    NSData *detailData;
    NSMutableDictionary *detailJson;
}

@end

@implementation SearchDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    
    
    
    self.headingLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, DEVICE_SIZE.width, title_hight)];
    self.headingLabel.backgroundColor=customGreen;
    self.headingLabel.textAlignment = NSTextAlignmentCenter;
    self.headingLabel.textColor = [UIColor whiteColor];
    self.headingLabel.clipsToBounds = YES;
    self.headingLabel.numberOfLines = 1;
    self.headingLabel.baselineAdjustment = YES;
    self.headingLabel.adjustsFontSizeToFitWidth = NO;
    [self.headingLabel setText:@"Details"];
    [self.headingLabel setFont:[UIFont boldSystemFontOfSize:18]];
    
    self.backBtn = [[UIButton alloc]initWithFrame:CGRectMake(title_padding, title_padding, title_logo_hight_width, title_logo_hight_width)];
    [self.backBtn setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [self.backBtn addTarget:self action:@selector(BackView:) forControlEvents:UIControlEventTouchUpInside];
    self.backBtn.adjustsImageWhenHighlighted = NO;
    self.backBtn.backgroundColor=[UIColor clearColor];
    self.backBtn.layer.borderWidth=0;
    self.backBtn.layer.cornerRadius=4;
    self.backBtn.clipsToBounds=YES;
    
    
    
    
    self.shareBtn = [[UIButton alloc]initWithFrame:CGRectMake(DEVICE_SIZE.width-5-20, 10, 24, 24)];
    [self.shareBtn setBackgroundImage:[UIImage imageNamed:@"moreoption@2x.png"] forState:UIControlStateNormal];
    [self.shareBtn addTarget:self action:@selector(ShareDetils:) forControlEvents:UIControlEventTouchUpInside];
    self.shareBtn.adjustsImageWhenHighlighted = NO;
    self.shareBtn.backgroundColor=[UIColor clearColor];
    self.shareBtn.layer.borderWidth=0;
    self.shareBtn.layer.cornerRadius=4;
    self.shareBtn.clipsToBounds=YES;
    
    
    [self.view addSubview:self.headingLabel];
    [self.view addSubview:self.backBtn];
    [self.view addSubview:self.shareBtn];
    
    [self CallWebServicesDetails];
    
    
}


-(void)SetUpDesign{
    
    self.detailScrollView = [[UIScrollView alloc] init];
    self.detailScrollView.frame =CGRectMake(0, title_hight, DEVICE_SIZE.width, DEVICE_SIZE.height-title_hight-49);
    self.detailScrollView.bounces=NO;
    //  self.verticalScrollView.backgroundColor = [UIColor lightGrayColor];
    self.detailScrollView.backgroundColor = [UIColor whiteColor];
    
    self.detailScrollView.showsVerticalScrollIndicator = NO;
    self.detailScrollView.showsHorizontalScrollIndicator = NO;
    self.detailScrollView.alwaysBounceVertical=NO;
    self.detailScrollView.alwaysBounceHorizontal=NO;
    self.detailScrollView.scrollEnabled = YES;
    self.detailScrollView.pagingEnabled=NO;
    
    
    
    
    
    self.bannerImage=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, DEVICE_SIZE.width, DEVICE_SIZE.height/4)];
    self.bannerImage.backgroundColor=[UIColor clearColor];
    [self.bannerImage setContentMode:UIViewContentModeScaleAspectFit];
    self.bannerImage.layer.cornerRadius = 2;
    self.bannerImage.layer.masksToBounds = YES;
    self.bannerImage.layer.borderWidth = 0;
    self.bannerImage.layer.borderColor=[[UIColor whiteColor] CGColor];
    
    [self.bannerImage sd_setImageWithPreviousCachedImageWithURL:[NSURL URLWithString:[detailJson objectForKey:@"Poster"]] andPlaceholderImage:[UIImage imageNamed:@"placeholder@2x.png"] options:SDWebImageRetryFailed progress:^(NSInteger receivedSize, NSInteger expectedSize) {
    } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        
    }];
    
    
    
    
    
    
    
    
    
    
    self.title_name=[[UILabel alloc]initWithFrame:CGRectMake(10, self.bannerImage.frame.origin.y+self.bannerImage.frame.size.height+10, DEVICE_SIZE.width/3, 30)];
    self.title_name.backgroundColor=[UIColor clearColor];
    self.title_name.textAlignment = NSTextAlignmentLeft;
    self.title_name.textColor = [UIColor darkGrayColor];
    self.title_name.clipsToBounds = YES;
    self.title_name.numberOfLines = 1;
    self.title_name.baselineAdjustment = YES;
    self.title_name.adjustsFontSizeToFitWidth = NO;
    [self.title_name setText:@"Title"];
    [self.title_name setFont:[UIFont boldSystemFontOfSize:16]];
    
    
    UILabel *t_name=[[UILabel alloc]initWithFrame:CGRectMake(self.self.title_name.frame.origin.x+self.title_name.frame.size.width+10, self.self.title_name.frame.origin.y,DEVICE_SIZE.width-self.self.title_name.frame.origin.x-self.title_name.frame.size.width-20, 30)];
    t_name.backgroundColor=[UIColor clearColor];
    t_name.textAlignment = NSTextAlignmentLeft;
    t_name.textColor = customGreen;
    t_name.clipsToBounds = YES;
    t_name.numberOfLines = 1;
    t_name.baselineAdjustment = YES;
    t_name.adjustsFontSizeToFitWidth = NO;
    [t_name setText:[NSString stringWithFormat:@"%@",[detailJson objectForKey:@"Title"]]];
    [t_name setFont:[UIFont boldSystemFontOfSize:16]];
    
    
    
    
    
    
    
    
    
    
    
    self.release_date=[[UILabel alloc]initWithFrame:CGRectMake(self.title_name.frame.origin.x, self.title_name.frame.origin.y+self.title_name.frame.size.height+5, self.title_name.frame.size.width, 30)];
    self.release_date.backgroundColor=[UIColor clearColor];
    self.release_date.textAlignment = NSTextAlignmentLeft;
    self.release_date.textColor = [UIColor darkGrayColor];
    self.release_date.clipsToBounds = YES;
    self.release_date.numberOfLines = 1;
    self.release_date.baselineAdjustment = YES;
    self.release_date.adjustsFontSizeToFitWidth = NO;
    [self.release_date setText:@"Released"];
    [self.release_date setFont:[UIFont boldSystemFontOfSize:16]];
    
    
    UILabel *r_date=[[UILabel alloc]initWithFrame:CGRectMake(t_name.frame.origin.x, t_name.frame.origin.y+t_name.frame.size.height+5,t_name.frame.size.width, 30)];
    r_date.backgroundColor=[UIColor clearColor];
    r_date.textAlignment = NSTextAlignmentLeft;
    r_date.textColor = customGreen;
    r_date.clipsToBounds = YES;
    r_date.numberOfLines = 1;
    r_date.baselineAdjustment = YES;
    r_date.adjustsFontSizeToFitWidth = NO;
    [r_date setText:[NSString stringWithFormat:@"%@",[detailJson objectForKey:@"Released"]]];
    [r_date setFont:[UIFont boldSystemFontOfSize:16]];
    

    
    
    
    
    
    self.run_time=[[UILabel alloc]initWithFrame:CGRectMake(self.release_date.frame.origin.x, self.release_date.frame.origin.y+self.release_date.frame.size.height+5, self.release_date.frame.size.width, 30)];
    self.run_time.backgroundColor=[UIColor clearColor];
    self.run_time.textAlignment = NSTextAlignmentLeft;
    self.run_time.textColor = [UIColor darkGrayColor];
    self.run_time.clipsToBounds = YES;
    self.run_time.numberOfLines = 1;
    self.run_time.baselineAdjustment = YES;
    self.run_time.adjustsFontSizeToFitWidth = NO;
    [self.run_time setText:@"Run Time"];
    [self.run_time setFont:[UIFont boldSystemFontOfSize:16]];
    
    
    UILabel *r_time=[[UILabel alloc]initWithFrame:CGRectMake(r_date.frame.origin.x, r_date.frame.origin.y+r_date.frame.size.height+5,r_date.frame.size.width, 30)];
    r_time.backgroundColor=[UIColor clearColor];
    r_time.textAlignment = NSTextAlignmentLeft;
    r_time.textColor = customGreen;
    r_time.clipsToBounds = YES;
    r_time.numberOfLines = 1;
    r_time.baselineAdjustment = YES;
    r_date.adjustsFontSizeToFitWidth = NO;
    [r_time setText:[NSString stringWithFormat:@"%@",[detailJson objectForKey:@"Runtime"]]];
    [r_time setFont:[UIFont boldSystemFontOfSize:16]];

    
    
    
    
    self.gener=[[UILabel alloc]initWithFrame:CGRectMake(self.run_time.frame.origin.x, self.run_time.frame.origin.y+self.run_time.frame.size.height+5, self.run_time.frame.size.width, 30)];
    self.gener.backgroundColor=[UIColor clearColor];
    self.gener.textAlignment = NSTextAlignmentLeft;
    self.gener.textColor = [UIColor darkGrayColor];
    self.gener.clipsToBounds = YES;
    self.gener.numberOfLines = 1;
    self.gener.baselineAdjustment = YES;
    self.gener.adjustsFontSizeToFitWidth = NO;
    [self.gener setText:@"Genre"];
    [self.gener setFont:[UIFont boldSystemFontOfSize:16]];
    
    
    UILabel *genre=[[UILabel alloc]initWithFrame:CGRectMake(r_time.frame.origin.x, r_time.frame.origin.y+r_time.frame.size.height+5,r_time.frame.size.width, 30)];
    genre.backgroundColor=[UIColor clearColor];
    genre.textAlignment = NSTextAlignmentLeft;
    genre.textColor = customGreen;
    genre.clipsToBounds = YES;
    genre.numberOfLines = 1;
    genre.baselineAdjustment = YES;
    genre.adjustsFontSizeToFitWidth = NO;
    [genre setText:[NSString stringWithFormat:@"%@",[detailJson objectForKey:@"Genre"]]];
    [genre setFont:[UIFont boldSystemFontOfSize:16]];

    
    
    
    
    
    self.languase=[[UILabel alloc]initWithFrame:CGRectMake(self.gener.frame.origin.x, self.gener.frame.origin.y+self.gener.frame.size.height+5, self.gener.frame.size.width, 30)];
    self.languase.backgroundColor=[UIColor clearColor];
    self.languase.textAlignment = NSTextAlignmentLeft;
    self.languase.textColor = [UIColor darkGrayColor];
    self.languase.clipsToBounds = YES;
    self.languase.numberOfLines = 1;
    self.languase.baselineAdjustment = YES;
    self.languase.adjustsFontSizeToFitWidth = NO;
    [self.languase setText:@"Languages"];
    [self.languase setFont:[UIFont boldSystemFontOfSize:16]];
    
    
    UILabel *lang=[[UILabel alloc]initWithFrame:CGRectMake(genre.frame.origin.x, genre.frame.origin.y+genre.frame.size.height+5,genre.frame.size.width, 30)];
    lang.backgroundColor=[UIColor clearColor];
    lang.textAlignment = NSTextAlignmentLeft;
    lang.textColor = customGreen;
    lang.clipsToBounds = YES;
    lang.numberOfLines = 1;
    lang.baselineAdjustment = YES;
    lang.adjustsFontSizeToFitWidth = NO;
    [lang setText:[NSString stringWithFormat:@"%@",[detailJson objectForKey:@"Language"]]];
    [lang setFont:[UIFont boldSystemFontOfSize:16]];
    
    
    
    
    
    
    self.director=[[UILabel alloc]initWithFrame:CGRectMake(self.languase.frame.origin.x, self.languase.frame.origin.y+self.languase.frame.size.height+5, self.run_time.frame.size.width, 30)];
    self.director.backgroundColor=[UIColor clearColor];
    self.director.textAlignment = NSTextAlignmentLeft;
    self.director.textColor = [UIColor darkGrayColor];
    self.director.clipsToBounds = YES;
    self.director.numberOfLines = 1;
    self.director.baselineAdjustment = YES;
    self.director.adjustsFontSizeToFitWidth = NO;
    [self.director setText:@"Director"];
    [self.director setFont:[UIFont boldSystemFontOfSize:16]];
    
    
    UILabel *dir=[[UILabel alloc]initWithFrame:CGRectMake(lang.frame.origin.x, lang.frame.origin.y+lang.frame.size.height+5,lang.frame.size.width, 30)];
    dir.backgroundColor=[UIColor clearColor];
    dir.textAlignment = NSTextAlignmentLeft;
    dir.textColor = customGreen;
    dir.clipsToBounds = YES;
    dir.numberOfLines = 1;
    dir.baselineAdjustment = YES;
    dir.adjustsFontSizeToFitWidth = NO;
    [dir setText:[NSString stringWithFormat:@"%@",[detailJson objectForKey:@"Director"]]];
    [dir setFont:[UIFont boldSystemFontOfSize:16]];
    
    
    
    
    
    
    
    
    self.actor=[[UILabel alloc]initWithFrame:CGRectMake(self.director.frame.origin.x, self.director.frame.origin.y+self.director.frame.size.height+5, self.director.frame.size.width, 30)];
    self.actor.backgroundColor=[UIColor clearColor];
    self.actor.textAlignment = NSTextAlignmentLeft;
    self.actor.textColor = [UIColor darkGrayColor];
    self.actor.clipsToBounds = YES;
    self.actor.numberOfLines = 1;
    self.actor.baselineAdjustment = YES;
    self.actor.adjustsFontSizeToFitWidth = NO;
    [self.actor setText:@"Actor"];
    [self.actor setFont:[UIFont boldSystemFontOfSize:16]];
    
    
    UILabel *act=[[UILabel alloc]initWithFrame:CGRectMake(dir.frame.origin.x, dir.frame.origin.y+dir.frame.size.height+5,dir.frame.size.width, 60)];
    act.backgroundColor=[UIColor clearColor];
    act.textAlignment = NSTextAlignmentLeft;
    act.textColor = customGreen;
    act.clipsToBounds = YES;
    act.numberOfLines = 3;
    act.baselineAdjustment = YES;
    act.adjustsFontSizeToFitWidth = NO;
    [act setText:[NSString stringWithFormat:@"%@",[detailJson objectForKey:@"Actors"]]];
    [act setFont:[UIFont boldSystemFontOfSize:16]];
    
    
    
    
    
    
    
    
    
    
    
    self.ploat=[[UILabel alloc]initWithFrame:CGRectMake(self.actor.frame.origin.x, self.actor.frame.origin.y+self.actor.frame.size.height+5+30, self.actor.frame.size.width, 30)];
    self.ploat.backgroundColor=[UIColor clearColor];
    self.ploat.textAlignment = NSTextAlignmentLeft;
    self.ploat.textColor = [UIColor darkGrayColor];
    self.ploat.clipsToBounds = YES;
    self.ploat.numberOfLines = 1;
    self.ploat.baselineAdjustment = YES;
    self.ploat.adjustsFontSizeToFitWidth = NO;
    [self.ploat setText:@"Ploat"];
    [self.ploat setFont:[UIFont boldSystemFontOfSize:16]];
    
    
    UILabel *plo=[[UILabel alloc]initWithFrame:CGRectMake(act.frame.origin.x, act.frame.origin.y+act.frame.size.height+5,act.frame.size.width, 60)];
    plo.backgroundColor=[UIColor clearColor];
    plo.textAlignment = NSTextAlignmentLeft;
    plo.textColor = customGreen;
    plo.clipsToBounds = YES;
    plo.numberOfLines = 4;
    plo.baselineAdjustment = YES;
    plo.adjustsFontSizeToFitWidth = NO;
    [plo setText:[NSString stringWithFormat:@"%@",[detailJson objectForKey:@"Plot"]]];
    [plo setFont:[UIFont boldSystemFontOfSize:16]];
    
    
    
    
    
    
    
    
    
    [self.detailScrollView addSubview:self.bannerImage];
    
    [self.detailScrollView addSubview:self.title_name];
    [self.detailScrollView addSubview:t_name];
    
    
    [self.detailScrollView addSubview:self.release_date];
    [self.detailScrollView addSubview:r_date];

    [self.detailScrollView addSubview:self.run_time];
    [self.detailScrollView addSubview:r_time];

    [self.detailScrollView addSubview:self.gener];
    [self.detailScrollView addSubview:genre];

    
    
    [self.detailScrollView addSubview:self.languase];
    [self.detailScrollView addSubview:lang];
    
    
    [self.detailScrollView addSubview:self.director];
    [self.detailScrollView addSubview:dir];
    
    [self.detailScrollView addSubview:self.actor];
    [self.detailScrollView addSubview:act];
    
    [self.detailScrollView addSubview:self.ploat];
    [self.detailScrollView addSubview:plo];

    
    
    
    
    [self.view addSubview:self.detailScrollView];
    
    self.detailScrollView.contentSize = CGSizeMake(DEVICE_SIZE.width ,plo.frame.origin.y+plo.frame.size.height+20);
    
    
    
}




-(void)CallWebServicesDetails
{
    
    
    
    
    detailsStr = [[NSString stringWithFormat:@"%@i=%@&plot=short&r=json&page=1",kBaseUrl,self.dbId] stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    
    
    
    NSLog(@"login string is with email :  %@ ",detailsStr);
    
    
    
    //    UIActivityIndicatorView *activityView = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    //    activityView.center=self.view.center;
    //    activityView.color=customGreenColor;
    //    activityView.hidesWhenStopped=YES;
    //    [self.view addSubview:activityView];
    //
    //    dispatch_async(dispatch_get_main_queue(), ^{
    //
    //        [activityView startAnimating];
    //    });
    
    dispatch_async(kBgQueue, ^{
        
        
        detailData = [NSData dataWithContentsOfURL:[NSURL URLWithString:detailsStr]];
        
        // NSString *sttr=[[NSString alloc] initWithData:myCourseData encoding:NSUTF8StringEncoding];
        // NSLog(@"data responce is : %@",sttr);
        
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if(detailData!=nil)
            {
                
                NSError* error;
                
                detailJson = [NSJSONSerialization
                              JSONObjectWithData:detailData
                              options:kNilOptions
                              error:&error];
                
                NSString *success_no=[NSString stringWithFormat:@"%@",[detailJson valueForKey:@"Response"]];
                if([success_no isEqualToString:@"True"])
                {
                    
                    [self SetUpDesign];
                    
                    
                }
                else if([success_no isEqualToString:@"False"])
                {
                    
                    
                    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_0) {
                        
                        
                        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"False Response." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                        [alert show];
                        
                        
                    } else {
                        UIAlertController * alert=   [UIAlertController alertControllerWithTitle:@"Alert"message:@"False Response." preferredStyle:UIAlertControllerStyleAlert];
                        UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"Ok"style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];
                        }];
                        
                        [alert addAction:cancelBtn];
                        [self presentViewController:alert animated:YES completion:nil];
                        
                        
                    }
                    
                }
                
                else{
                    
                    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_0) {
                        
                        
                        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert" message:[detailJson valueForKey:@"Response"] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                        [alert show];
                        
                        
                    } else {
                        UIAlertController * alert=   [UIAlertController alertControllerWithTitle:@"Alert"message:[detailJson valueForKey:@"Response"] preferredStyle:UIAlertControllerStyleAlert];
                        UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"Ok"style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];
                        }];
                        
                        [alert addAction:cancelBtn];
                        [self presentViewController:alert animated:YES completion:nil];
                        
                        
                    }
                    
                    
                }
                
            }
            else
            {
                
                if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_0) {
                    
                    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Internet is not working on your device." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                    [alert show];
                    
                } else {
                    UIAlertController * alert=   [UIAlertController alertControllerWithTitle:@"Alert"message:@"Internet is not working on your device." preferredStyle:UIAlertControllerStyleAlert];
                    UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"Ok"style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                        [alert dismissViewControllerAnimated:YES completion:nil];
                    }];
                    
                    [alert addAction:cancelBtn];
                    [self presentViewController:alert animated:YES completion:nil];
                    
                }
                
            }
            
            
            
            
        });
        
        // [activityView stopAnimating];
        
    });
    
}







-(void)BackView:(UIButton *)sender{
    
    [self.navigationController popViewControllerAnimated:NO];
    
    
}


-(void)ShareDetils:(UIButton *)sender{
    
    
    
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        
        
        
        
        
        NSString* text=@"By RBP ";
        NSURL *myWebsite = [NSURL URLWithString:@"itms-apps://itunes.apple.com/app/id1022762275"];
        NSArray* sharedObjects=@[text,myWebsite];
        UIActivityViewController * activityViewController=[[UIActivityViewController alloc]initWithActivityItems:sharedObjects applicationActivities:nil];
        
        UIPopoverPresentationController *popPresenter = [activityViewController popoverPresentationController];
        popPresenter.sourceView = self.shareBtn;
        popPresenter.sourceRect = self.shareBtn.bounds;
        [self presentViewController:activityViewController animated:YES completion:nil];
        
        
        
        
    }
    else
    {
        
        
        
        
        
        //            if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_0) {
        //
        //
        //                UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Select" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Feedback",@"Reset Course",@"Add to favourite",@"Delete Offline Content",nil];
        //
        //                [actionSheet showInView:self.view];
        //
        //
        //
        //            } else {
        //
        //
        //            }
        
        
        
        
        NSString* text=@"By RAM ";
        NSURL *myWebsite = [NSURL URLWithString:@"itms-apps://itunes.apple.com/app/id1022762275"];
        NSArray* sharedObjects=@[text,myWebsite];
        UIActivityViewController * activityViewController=[[UIActivityViewController alloc]initWithActivityItems:sharedObjects applicationActivities:nil];
        activityViewController.popoverPresentationController.sourceView = self.view;
        [self presentViewController:activityViewController animated:YES completion:nil];
        
        
        
        
        
    }
}

- (UIDocumentInteractionController *) setupControllerWithURL: (NSURL*) fileURL

                                               usingDelegate: (id ) interactionDelegate {
    
    
    
    self.documentationInteractionController =
    
    [UIDocumentInteractionController interactionControllerWithURL: fileURL];
    
    self.documentationInteractionController.delegate = interactionDelegate;
    
    
    
    return self.documentationInteractionController;
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
