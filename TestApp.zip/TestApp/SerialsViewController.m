//
//  SerialsViewController.m
//  TestApp
//
//  Created by WeMited Mac 3 on 15/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#import "SerialsViewController.h"

@interface SerialsViewController ()

{
    NSString *serialStr;
    NSData *serialData;
    NSMutableDictionary *serialJson;
}

@end

@implementation SerialsViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor=[UIColor whiteColor];
    
    
    
    self.headingLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, DEVICE_SIZE.width, title_hight)];
    self.headingLabel.backgroundColor=customGreen;
    self.headingLabel.textAlignment = NSTextAlignmentCenter;
    self.headingLabel.textColor = [UIColor whiteColor];
    self.headingLabel.clipsToBounds = YES;
    self.headingLabel.numberOfLines = 1;
    self.headingLabel.baselineAdjustment = YES;
    self.headingLabel.adjustsFontSizeToFitWidth = NO;
    [self.headingLabel setText:@"Details"];
    [self.headingLabel setFont:[UIFont boldSystemFontOfSize:18]];
    
    self.backBtn = [[UIButton alloc]initWithFrame:CGRectMake(title_padding, title_padding, title_logo_hight_width, title_logo_hight_width)];
    [self.backBtn setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [self.backBtn addTarget:self action:@selector(BackViewSelector:) forControlEvents:UIControlEventTouchUpInside];
    self.backBtn.adjustsImageWhenHighlighted = NO;
    self.backBtn.backgroundColor=[UIColor clearColor];
    self.backBtn.layer.borderWidth=0;
    self.backBtn.layer.cornerRadius=4;
    self.backBtn.clipsToBounds=YES;
    
    
    [self.view addSubview:self.headingLabel];
    [self.view addSubview:self.backBtn];
    [self SetUpDesign];
    
}

-(void)SetUpDesign{
    
    
    
    
    self.seriaseTable=[[UITableView alloc]initWithFrame:CGRectMake(0, title_hight, DEVICE_SIZE.width, DEVICE_SIZE.height-title_hight-49)];
    self.seriaseTable.backgroundColor=[UIColor whiteColor];
    self.seriaseTable.separatorStyle=UITableViewCellSelectionStyleNone;
    self.seriaseTable.bounces=YES;
    
    
    
    [self CallWebServicesSerial];
    
}


-(void)CallWebServicesSerial
{
    
    
    
   // http://www.omdbapi.com/?t=game%20of%20thrones&y=&plot=short&r=json&type=series&Season=1&Episode=1
    
    
    serialStr = [[NSString stringWithFormat:@"%@t=%@&plot=short&r=json&page=1&Season=1",kBaseUrl,self.sendDBId] stringByReplacingOccurrencesOfString:@" " withString:@"%20"];

//    http://www.omdbapi.com/?t=game%20of%20thrones&plot=short&r=json&page=1&season=1
//    http://www.omdbapi.com/?t=Game%20of%20Thrones&plot=short&r=json&page=1&seasion=1
    
    
    NSLog(@"login string is with email :  %@ ",serialStr);
    
    
    
    //    UIActivityIndicatorView *activityView = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    //    activityView.center=self.view.center;
    //    activityView.color=customGreenColor;
    //    activityView.hidesWhenStopped=YES;
    //    [self.view addSubview:activityView];
    //
    //    dispatch_async(dispatch_get_main_queue(), ^{
    //
    //        [activityView startAnimating];
    //    });
    
    dispatch_async(kBgQueue, ^{
        
        
        serialData = [NSData dataWithContentsOfURL:[NSURL URLWithString:serialStr]];
        
        // NSString *sttr=[[NSString alloc] initWithData:myCourseData encoding:NSUTF8StringEncoding];
        // NSLog(@"data responce is : %@",sttr);
        
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if(serialData!=nil)
            {
                
                NSError* error;
                
                serialJson = [NSJSONSerialization
                              JSONObjectWithData:serialData
                              options:kNilOptions
                              error:&error];
                
                NSString *success_no=[NSString stringWithFormat:@"%@",[serialJson valueForKey:@"Response"]];
                if([success_no isEqualToString:@"True"])
                {
                    [self.view addSubview:self.seriaseTable];
                    [self.seriaseTable setDelegate:self];
                    [self.seriaseTable setDataSource:self];
                    [self.seriaseTable reloadData];
                    

                    
                }
                else if([success_no isEqualToString:@"False"])
                {
                    
                    
                    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_0) {
                        
                        
                        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"False Response." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                        [alert show];
                        
                        
                    } else {
                        UIAlertController * alert=   [UIAlertController alertControllerWithTitle:@"Alert"message:@"False Response." preferredStyle:UIAlertControllerStyleAlert];
                        UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"Ok"style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];
                        }];
                        
                        [alert addAction:cancelBtn];
                        [self presentViewController:alert animated:YES completion:nil];
                        
                        
                    }
                    
                }
                
                else{
                    
                    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_0) {
                        
                        
                        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert" message:[serialJson valueForKey:@"Response"] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                        [alert show];
                        
                        
                    } else {
                        UIAlertController * alert=   [UIAlertController alertControllerWithTitle:@"Alert"message:[serialJson valueForKey:@"Response"] preferredStyle:UIAlertControllerStyleAlert];
                        UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"Ok"style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];
                        }];
                        
                        [alert addAction:cancelBtn];
                        [self presentViewController:alert animated:YES completion:nil];
                        
                        
                    }
                    
                    
                }
                
            }
            else
            {
                
                if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_0) {
                    
                    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Internet is not working on your device." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                    [alert show];
                    
                } else {
                    UIAlertController * alert=   [UIAlertController alertControllerWithTitle:@"Alert"message:@"Internet is not working on your device." preferredStyle:UIAlertControllerStyleAlert];
                    UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"Ok"style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                        [alert dismissViewControllerAnimated:YES completion:nil];
                    }];
                    
                    [alert addAction:cancelBtn];
                    [self presentViewController:alert animated:YES completion:nil];
                    
                }
                
            }
            
            
            
            
        });
        
        // [activityView stopAnimating];
        
    });
    
}




-(void)BackViewSelector:(UIButton *)sender{
    [self.navigationController popViewControllerAnimated:NO];
}

#pragma mark - tableView Delegates


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return [[serialJson objectForKey:@"Episodes"] count];
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 110;
}


- (void)searchDisplayController:(UISearchDisplayController *)controller didLoadSearchResultsTableView:(UITableView *)tableView
{
    tableView.rowHeight = 80;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    static NSString *simpleTableIdentifier = @"cell";
    
    SerialViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    
    if (cell == nil) {
        cell = [[SerialViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
        
        
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    
    if (indexPath.row%2==0) {
        cell.backgroundColor=[UIColor lightGrayColor];
        
    }
    else{
        cell.backgroundColor=[UIColor lightGrayColor];
        
    }
    
    
    [cell.backgroundLabel.layer setBorderColor:[UIColor whiteColor].CGColor];
    [cell.backgroundLabel.layer setBorderWidth:1.0f];
    cell.backgroundLabel.layer.cornerRadius=2;
    cell.backgroundLabel.backgroundColor=[UIColor whiteColor];
    
    
    cell.images.backgroundColor=[UIColor clearColor];
    [cell.images setContentMode:UIViewContentModeScaleAspectFit];
    cell.images.layer.cornerRadius = 2;
    cell.images.layer.masksToBounds = YES;
    cell.images.layer.borderWidth = 0;
    cell.images.layer.borderColor=[[UIColor whiteColor] CGColor];
    
    [cell.images sd_setImageWithPreviousCachedImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",self.previousImages]] andPlaceholderImage:[UIImage imageNamed:@"placeholder@2x.png"] options:SDWebImageRetryFailed progress:^(NSInteger receivedSize, NSInteger expectedSize) {
        
    } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        
    }];

    
    
    
    
    cell.titleName.backgroundColor=[UIColor clearColor];
    cell.titleName.textAlignment = NSTextAlignmentLeft;
    cell.titleName.textColor = customGreenTextColor;
    cell.titleName.clipsToBounds = YES;
    cell.titleName.baselineAdjustment = YES;
    cell.titleName.adjustsFontSizeToFitWidth = NO;
    [cell.titleName setFont:[UIFont boldSystemFontOfSize:14]];
    cell.titleName.text=[NSString stringWithFormat:@"%@ . %@",[[[serialJson objectForKey:@"Episodes"] objectAtIndex:indexPath.row] objectForKey:@"Episode"],[[[serialJson objectForKey:@"Episodes"] objectAtIndex:indexPath.row] objectForKey:@"Title"]];
    
    
    
    
    
    cell.releaseDate.backgroundColor=[UIColor clearColor];
    cell.releaseDate.textAlignment = NSTextAlignmentLeft;
    cell.releaseDate.textColor = customGreenTextColor;
    cell.releaseDate.clipsToBounds = YES;
    cell.releaseDate.numberOfLines = 1;
    cell.releaseDate.baselineAdjustment = YES;
    cell.releaseDate.adjustsFontSizeToFitWidth = NO;
    [cell.releaseDate setFont:[UIFont fontWithName:@"Helvetica" size:12]];
    
    cell.releaseDate.text=[NSString stringWithFormat:@"%@",[[[serialJson objectForKey:@"Episodes"] objectAtIndex:indexPath.row] objectForKey:@"Released"]];

    
    
    
    
    return cell;
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
        SearchDetailViewController *search_Detail=[[SearchDetailViewController alloc]init];
    
    search_Detail.dbId=[NSString stringWithFormat:@"%@",[[[serialJson objectForKey:@"Episodes"] objectAtIndex:indexPath.row] objectForKey:@"imdbID"]];

        [self.navigationController pushViewController:search_Detail animated:NO];
   
    
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
