//
//  SerialsViewController.m
//  TestApp
//
//  Created by WeMited Mac 3 on 15/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#import "SerialsViewController.h"

@interface SerialsViewController ()

{
    NSString *serialStr;
    NSData *serialData;
    NSMutableDictionary *serialJson;
}

@end

@implementation SerialsViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor=[UIColor whiteColor];
    
    
    
    self.headingLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, DEVICE_SIZE.width, title_hight)];
    self.headingLabel.backgroundColor=customGreen;
    self.headingLabel.textAlignment = NSTextAlignmentCenter;
    self.headingLabel.textColor = [UIColor whiteColor];
    self.headingLabel.clipsToBounds = YES;
    self.headingLabel.numberOfLines = 1;
    self.headingLabel.baselineAdjustment = YES;
    self.headingLabel.adjustsFontSizeToFitWidth = NO;
    [self.headingLabel setText:@"Details"];
    [self.headingLabel setFont:[UIFont boldSystemFontOfSize:18]];
    
    self.backBtn = [[UIButton alloc]initWithFrame:CGRectMake(title_padding, title_padding, title_logo_hight_width, title_logo_hight_width)];
    [self.backBtn setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    [self.backBtn addTarget:self action:@selector(BackViewSelector:) forControlEvents:UIControlEventTouchUpInside];
    self.backBtn.adjustsImageWhenHighlighted = NO;
    self.backBtn.backgroundColor=[UIColor clearColor];
    self.backBtn.layer.borderWidth=0;
    self.backBtn.layer.cornerRadius=4;
    self.backBtn.clipsToBounds=YES;
    
    
    [self.view addSubview:self.headingLabel];
    [self.view addSubview:self.backBtn];
    [self SetUpDesign];
    
}

-(void)SetUpDesign{
    
    
    
    
    self.seriaseTable=[[UITableView alloc]initWithFrame:CGRectMake(0, title_hight, DEVICE_SIZE.width, DEVICE_SIZE.height-title_hight-49)];
    self.seriaseTable.backgroundColor=[UIColor whiteColor];
    self.seriaseTable.separatorStyle=UITableViewCellSelectionStyleNone;
    self.seriaseTable.bounces=YES;
    
    
    
    [self CallWebServicesSerial];
    
}


-(void)CallWebServicesSerial
{
    
    
    
   // http://www.omdbapi.com/?t=game%20of%20thrones&y=&plot=short&r=json&type=series&Season=1&Episode=1
    
    
    serialStr = [[NSString stringWithFormat:@"%@i=%@&plot=short&r=json&page=1&Seasion=1&type=series",kBaseUrl,self.sendDBId] stringByReplacingOccurrencesOfString:@" " withString:@"%20"];

    
    
    NSLog(@"login string is with email :  %@ ",serialStr);
    
    
    
    //    UIActivityIndicatorView *activityView = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    //    activityView.center=self.view.center;
    //    activityView.color=customGreenColor;
    //    activityView.hidesWhenStopped=YES;
    //    [self.view addSubview:activityView];
    //
    //    dispatch_async(dispatch_get_main_queue(), ^{
    //
    //        [activityView startAnimating];
    //    });
    
    dispatch_async(kBgQueue, ^{
        
        
        serialData = [NSData dataWithContentsOfURL:[NSURL URLWithString:serialStr]];
        
        // NSString *sttr=[[NSString alloc] initWithData:myCourseData encoding:NSUTF8StringEncoding];
        // NSLog(@"data responce is : %@",sttr);
        
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if(serialData!=nil)
            {
                
                NSError* error;
                
                serialJson = [NSJSONSerialization
                              JSONObjectWithData:serialData
                              options:kNilOptions
                              error:&error];
                
                NSString *success_no=[NSString stringWithFormat:@"%@",[serialJson valueForKey:@"Response"]];
                if([success_no isEqualToString:@"True"])
                {
                    [self.view addSubview:self.seriaseTable];
                    [self.seriaseTable setDelegate:self];
                    [self.seriaseTable setDataSource:self];
                    [self.seriaseTable reloadData];
                    

                    
                }
                else if([success_no isEqualToString:@"False"])
                {
                    
                    
                    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_0) {
                        
                        
                        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"False Response." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                        [alert show];
                        
                        
                    } else {
                        UIAlertController * alert=   [UIAlertController alertControllerWithTitle:@"Alert"message:@"False Response." preferredStyle:UIAlertControllerStyleAlert];
                        UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"Ok"style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];
                        }];
                        
                        [alert addAction:cancelBtn];
                        [self presentViewController:alert animated:YES completion:nil];
                        
                        
                    }
                    
                }
                
                else{
                    
                    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_0) {
                        
                        
                        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert" message:[serialJson valueForKey:@"Response"] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                        [alert show];
                        
                        
                    } else {
                        UIAlertController * alert=   [UIAlertController alertControllerWithTitle:@"Alert"message:[serialJson valueForKey:@"Response"] preferredStyle:UIAlertControllerStyleAlert];
                        UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"Ok"style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];
                        }];
                        
                        [alert addAction:cancelBtn];
                        [self presentViewController:alert animated:YES completion:nil];
                        
                        
                    }
                    
                    
                }
                
            }
            else
            {
                
                if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_0) {
                    
                    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Internet is not working on your device." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                    [alert show];
                    
                } else {
                    UIAlertController * alert=   [UIAlertController alertControllerWithTitle:@"Alert"message:@"Internet is not working on your device." preferredStyle:UIAlertControllerStyleAlert];
                    UIAlertAction *cancelBtn = [UIAlertAction actionWithTitle:@"Ok"style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                        [alert dismissViewControllerAnimated:YES completion:nil];
                    }];
                    
                    [alert addAction:cancelBtn];
                    [self presentViewController:alert animated:YES completion:nil];
                    
                }
                
            }
            
            
            
            
        });
        
        // [activityView stopAnimating];
        
    });
    
}




-(void)BackViewSelector:(UIButton *)sender{
    [self.navigationController popViewControllerAnimated:NO];
}

#pragma mark - tableView Delegates


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 10;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 110;
}


- (void)searchDisplayController:(UISearchDisplayController *)controller didLoadSearchResultsTableView:(UITableView *)tableView
{
    tableView.rowHeight = 80;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    static NSString *simpleTableIdentifier = @"cell";
    
    SerialViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    
    if (cell == nil) {
        cell = [[SerialViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
        
        
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    
    if (indexPath.row%2==0) {
        cell.backgroundColor=[UIColor lightGrayColor];
        
    }
    else{
        cell.backgroundColor=[UIColor lightGrayColor];
        
    }
    
    
    [cell.backgroundLabel.layer setBorderColor:[UIColor whiteColor].CGColor];
    [cell.backgroundLabel.layer setBorderWidth:1.0f];
    cell.backgroundLabel.layer.cornerRadius=2;
    cell.backgroundLabel.backgroundColor=[UIColor whiteColor];
    
    
    cell.images.backgroundColor=[UIColor yellowColor];
    [cell.images setContentMode:UIViewContentModeScaleAspectFit];
    cell.images.layer.cornerRadius = 2;
    cell.images.layer.masksToBounds = YES;
    cell.images.layer.borderWidth = 0;
    cell.images.layer.borderColor=[[UIColor whiteColor] CGColor];
    
    
//    [cell.images sd_setImageWithPreviousCachedImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[[wishListsCourseJson objectForKey:@"post"] objectAtIndex:indexPath.row] objectForKey:@"image_path"]]] andPlaceholderImage:[UIImage imageNamed:@"place512@2x.png"] options:SDWebImageRetryFailed progress:^(NSInteger receivedSize, NSInteger expectedSize) {
//        
//    } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
//        
//    }];

    
    
    
    
    cell.titleName.backgroundColor=[UIColor blueColor];
    cell.titleName.textAlignment = NSTextAlignmentLeft;
    cell.titleName.textColor = customGreenTextColor;
    cell.titleName.clipsToBounds = YES;
    cell.titleName.baselineAdjustment = YES;
    cell.titleName.adjustsFontSizeToFitWidth = NO;
    [cell.titleName setFont:[UIFont boldSystemFontOfSize:14]];
    
    
    
    
    
    
    cell.releaseDate.backgroundColor=[UIColor redColor];
    cell.releaseDate.textAlignment = NSTextAlignmentLeft;
    cell.releaseDate.textColor = customGreenTextColor;
    cell.releaseDate.clipsToBounds = YES;
    cell.releaseDate.numberOfLines = 1;
    cell.releaseDate.baselineAdjustment = YES;
    cell.releaseDate.adjustsFontSizeToFitWidth = NO;
    [cell.releaseDate setFont:[UIFont fontWithName:@"Helvetica" size:12]];
    
    
    
    
    
    
    /*
     
     
     // cell.courseImage.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[[[myCourseJson objectForKey:@"post"] objectAtIndex:0] objectForKey:@"image"] ]]];
     
     
     
     
     
     cell.course_title.backgroundColor=[UIColor clearColor];
     cell.course_title.textAlignment = NSTextAlignmentLeft;
     cell.course_title.textColor = customGreenTextColor;
     cell.course_title.clipsToBounds = YES;
     cell.course_title.baselineAdjustment = YES;
     cell.course_title.adjustsFontSizeToFitWidth = NO;
     [cell.course_title setFont:[UIFont boldSystemFontOfSize:14]];
     
     
     
     
     
     cell.course_updated_time.backgroundColor=[UIColor clearColor];
     cell.course_updated_time.textAlignment = NSTextAlignmentLeft;
     cell.course_updated_time.textColor = customGreenTextColor;
     cell.course_updated_time.clipsToBounds = YES;
     cell.course_updated_time.numberOfLines = 1;
     cell.course_updated_time.baselineAdjustment = YES;
     cell.course_updated_time.adjustsFontSizeToFitWidth = NO;
     [cell.course_updated_time setFont:[UIFont fontWithName:@"Helvetica" size:12]];
     
     
     
     
     cell.degreeImage.backgroundColor=[UIColor clearColor];
     cell.degreeImage.image=[UIImage imageNamed:@"winner@2x.png"];
     [cell.degreeImage setContentMode:UIViewContentModeScaleAspectFit];
     cell.degreeImage.layer.cornerRadius = 2;
     cell.degreeImage.layer.masksToBounds = YES;
     cell.degreeImage.layer.borderWidth = 0;
     cell.degreeImage.layer.borderColor=[[UIColor whiteColor] CGColor];
     
     
     
     
     
     cell.ribbonView.backgroundColor=[UIColor clearColor];
     cell.ribbonView.clipsToBounds=YES;
     
     
     
     cell.discountRibbonLabel.backgroundColor=[UIColor redColor];
     cell.discountRibbonLabel.textAlignment = NSTextAlignmentCenter;
     cell.discountRibbonLabel.textColor = [UIColor whiteColor];
     cell.discountRibbonLabel.clipsToBounds = YES;
     cell.discountRibbonLabel.numberOfLines = 1;
     cell.discountRibbonLabel.baselineAdjustment = YES;
     cell.discountRibbonLabel.adjustsFontSizeToFitWidth = NO;
     [cell.discountRibbonLabel setFont:[UIFont boldSystemFontOfSize:16]];
     cell.discountRibbonLabel.text=@"10%";
     
     cell.discountRibbonLabel.transform = CGAffineTransformMakeRotation(M_PI /4);
     
     
     
     if ((searchText.length >0) || ([row_no count]>0)) {
     
     NSNumber *anumber = [row_no objectAtIndex:indexPath.row];
     int index = [anumber intValue];
     
     
     
     [cell.courseImage sd_setImageWithPreviousCachedImageWithURL:[NSURL URLWithString:[[[myCourseJson objectForKey:@"post"] objectAtIndex:index] objectForKey:@"image_path"] ] andPlaceholderImage:[UIImage imageNamed:@"place512@2x.png"] options:SDWebImageRetryFailed progress:^(NSInteger receivedSize, NSInteger expectedSize) {
     
     } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
     
     }];
     
     
     [cell.course_title setText:[NSString stringWithFormat:@"%@",[[[myCourseJson objectForKey:@"post"] objectAtIndex:index] objectForKey:@"course_title"]]];
     
     
     
     // [cell.institute_name setText:[NSString stringWithFormat:@"%@",[[[myCourseJson objectForKey:@"post"] objectAtIndex:index] objectForKey:@"course_sub_title"]]];
     
     [cell.course_updated_time setText:[NSString stringWithFormat:@"%@",[[[myCourseJson objectForKey:@"post"] objectAtIndex:index]objectForKey:@"times_ago"]]];
     
     
     
     
     
     cell.progressCompleteColor.frame=CGRectMake(cell.course_updated_time.frame.origin.x ,cell.course_updated_time.frame.origin.y+cell.course_updated_time.frame.size.height+2,cell.course_updated_time.frame.size.width/100*[[[[myCourseJson objectForKey:@"post"] objectAtIndex:index] objectForKey:@"course_completed_percent"] intValue],2);
     
     
     if ([[[[myCourseJson objectForKey:@"post"] objectAtIndex:index] objectForKey:@"course_completed_percent"] isEqualToString:@"0"]) {
     cell.progressCompleteInPersentage.text=[NSString stringWithFormat:@"Start Course"];
     cell.progressCompleteInPersentage.textColor = myanuGreenColor;
     
     }
     else{
     cell.progressCompleteInPersentage.text=[NSString stringWithFormat:@"%d%% completed",[[[[myCourseJson objectForKey:@"post"] objectAtIndex:index] objectForKey:@"course_completed_percent"] intValue]];
     cell.progressCompleteInPersentage.textColor = customGreenTextColor;
     
     }
     
     
     
     }else{
     
     
     
     
     
     
     [cell.courseImage sd_setImageWithPreviousCachedImageWithURL:[NSURL URLWithString:[[[myCourseJson objectForKey:@"post"] objectAtIndex:indexPath.row] objectForKey:@"image_path"] ] andPlaceholderImage:[UIImage imageNamed:@"place512@2x.png"] options:SDWebImageRetryFailed progress:^(NSInteger receivedSize, NSInteger expectedSize) {
     
     } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
     
     }];
     
     
     [cell.course_title setText:[NSString stringWithFormat:@"%@",[[[myCourseJson objectForKey:@"post"] objectAtIndex:indexPath.row] objectForKey:@"course_title"]]];
     
     
     
     // [cell.institute_name setText:[NSString stringWithFormat:@"%@",[[[myCourseJson objectForKey:@"post"] objectAtIndex:indexPath.row] objectForKey:@"course_sub_title"]]];
     
     [cell.course_updated_time setText:[NSString stringWithFormat:@"%@",[[[myCourseJson objectForKey:@"post"] objectAtIndex:indexPath.row]objectForKey:@"times_ago"]]];
     
     
     
     cell.progressCompleteColor.frame=CGRectMake(cell.course_updated_time.frame.origin.x ,cell.course_updated_time.frame.origin.y+cell.course_updated_time.frame.size.height+2,cell.course_updated_time.frame.size.width/100*[[[[myCourseJson objectForKey:@"post"] objectAtIndex:indexPath.row] objectForKey:@"course_completed_percent"] intValue],2);
     
     
     
     if ([[[[myCourseJson objectForKey:@"post"] objectAtIndex:indexPath.row] objectForKey:@"course_completed_percent"] isEqualToString:@"0"]) {
     cell.progressCompleteInPersentage.text=[NSString stringWithFormat:@"Start Course"];
     cell.progressCompleteInPersentage.textColor = myanuGreenColor;
     
     }
     else{
     cell.progressCompleteInPersentage.text=[NSString stringWithFormat:@"%d%% completed",[[[[myCourseJson objectForKey:@"post"] objectAtIndex:indexPath.row] objectForKey:@"course_completed_percent"] intValue]];
     cell.progressCompleteInPersentage.textColor = customGreenTextColor;
     
     }
     
     
     }
     
     if (indexPath.row) {
     dispatch_async(dispatch_get_main_queue(), ^{
     cell.course_title.numberOfLines = 0;
     [cell.course_title sizeToFit];
     
     });
     
     }else if (indexPath.row==0) {
     dispatch_async(dispatch_get_main_queue(), ^{
     cell.course_title.numberOfLines = 0;
     [cell.course_title sizeToFit];
     
     });
     
     }
     else{
     
     }
     
     
     
     */
    
    return cell;
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
        SearchDetailViewController *search_Detail=[[SearchDetailViewController alloc]init];
        [self.navigationController pushViewController:search_Detail animated:NO];
   
    
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
