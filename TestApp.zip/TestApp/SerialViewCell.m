//
//  SerialViewCell.m
//  TestApp
//
//  Created by WeMited Mac 3 on 15/04/16.
//  Copyright © 2016 WeMited Mac 3. All rights reserved.
//

#import "SerialViewCell.h"

@implementation SerialViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.images=[[UIImageView alloc]initWithFrame:CGRectMake(4, 5, 165 , 165*3/5)];
        
        self.titleName=[[UILabel alloc]initWithFrame:CGRectMake(165+4+4 ,10,DEVICE_SIZE.width-165-4-4-4, 40 )];
        
        self.releaseDate=[[UILabel alloc]initWithFrame:CGRectMake(self.titleName.frame.origin.x ,self.titleName.frame.origin.y+self.titleName.frame.size.height+5,self.titleName.frame.size.width, 40 )];

        self.backgroundLabel=[[UILabel alloc]initWithFrame:CGRectMake(0,0, DEVICE_SIZE.width,109)];
        
        
        
        [self addSubview:self.backgroundLabel];
        [self addSubview:self.images];
        [self addSubview:self.titleName];
        [self addSubview:self.releaseDate];
        
        
        
    }
    return self;
}



@end
